//Definimos variables globales a utilizar
var numeroUno, numeroDos, tipoOperacion, resultado;
//Definimos una función para limpiar la pantalla
function fnLimpiarDisplay(){
    display.value = " ";
}
//Definimos una función para marcar los números en la pantalla
function fnMarcarBoton(n){
    display.value = display.value + n;
}
//Definimos una función para recibir la operacion
function fnOperacion(op){
    numeroUno = Number(display.value); //Convertimos el valor que hay en el display en numérico
    fnLimpiarDisplay(); //Limpiamos la pantalla
    tipoOperacion = op; //Variable tipoOperacion le asignamos lo que viene del parámetro op
}
//Definimos una función para el botón igual (operar)
function fnOperar(){
    numeroDos = Number(display.value); //Convertimos el valor que hay en el display a numérico
    fnLimpiarDisplay(); //Limpiar la pantalla
    //Utilizamos una estructura de control condicional para evaluar el tipo de operación a realizar
    switch(tipoOperacion){   
        case 1: 
            resultado = numeroUno + numeroDos; 
        break;
        case 2:
            resultado = numeroUno - numeroDos;
        break;
        case 3:
            resultado = numeroUno * numeroDos;
        break;
        case 4:
            resultado = numeroUno / numeroDos;
        break;
        case 5:
            resultado = Math.pow(numeroUno,numeroDos);
        break;
    }
    display.value = resultado.toFixed(2);
}
//Definimos una función para cambio de signo
function fnCambiarSigno(){
    display.value = Number(display.value) * -1;   
}
//Definimos una función para el botón de porcentaje
function fnPorcentaje(){
    numeroDos = Number(display.value); //Convertimos el valor a numérico y lo almacenamos en numeroDos
    fnLimpiarDisplay(); //Llamamos  a la función para limpiar la pantalla
    resultado = numeroUno * (numeroDos/100); //Calculamos el porcentaje y lo almacenamos en resultado
    display.value = resultado.toFixed(2);  //Mostramos el resultado en la pantalla
}